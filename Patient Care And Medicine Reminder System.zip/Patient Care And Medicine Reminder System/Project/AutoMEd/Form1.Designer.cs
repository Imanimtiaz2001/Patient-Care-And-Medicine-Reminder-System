﻿namespace AutoMEd
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PatSubmit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.TextboxPatName = new System.Windows.Forms.TextBox();
            this.TextboxDocName = new System.Windows.Forms.TextBox();
            this.TextboxNurName = new System.Windows.Forms.TextBox();
            this.TextboxNMT = new System.Windows.Forms.TextBox();
            this.TextboxMT1 = new System.Windows.Forms.TextBox();
            this.TextboxNCT = new System.Windows.Forms.TextBox();
            this.TextboxCT1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TextboxMT2 = new System.Windows.Forms.TextBox();
            this.TextboxMT3 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.TextboxCT2 = new System.Windows.Forms.TextBox();
            this.TextboxCT3 = new System.Windows.Forms.TextBox();
            this.Adddoctor = new System.Windows.Forms.Button();
            this.Addpatient = new System.Windows.Forms.Button();
            this.Addnurse = new System.Windows.Forms.Button();
            this.SearchPatient = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.LabelDateTime = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.TextboxPatRoomNo = new System.Windows.Forms.TextBox();
            this.TextboxPatId = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.comboboxNurName = new System.Windows.Forms.ComboBox();
            this.comboboxDocName = new System.Windows.Forms.ComboBox();
            this.buttonback = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.buttonback2 = new System.Windows.Forms.Button();
            this.ButtonDocSubmit = new System.Windows.Forms.Button();
            this.TextboxDocId = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.TextboxNurId = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.buttonback3 = new System.Windows.Forms.Button();
            this.buttonNurSubmit = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.LabelPatID = new System.Windows.Forms.Label();
            this.LabelPatientName = new System.Windows.Forms.Label();
            this.LabelRoomNo = new System.Windows.Forms.Label();
            this.LabelNurseName = new System.Windows.Forms.Label();
            this.LabelDocName = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.TextboxPatSearch = new System.Windows.Forms.TextBox();
            this.buttonback4 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PatSubmit
            // 
            this.PatSubmit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.PatSubmit.Font = new System.Drawing.Font("Microsoft PhagsPa", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatSubmit.Location = new System.Drawing.Point(431, 382);
            this.PatSubmit.Name = "PatSubmit";
            this.PatSubmit.Size = new System.Drawing.Size(95, 35);
            this.PatSubmit.TabIndex = 0;
            this.PatSubmit.Text = "Submit";
            this.PatSubmit.UseVisualStyleBackColor = false;
            this.PatSubmit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 0);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(170, 0, 0, 0);
            this.label1.Size = new System.Drawing.Size(590, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Patient Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(137, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Full Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(33, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Doctor Name";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(285, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "Nurse Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(465, 24);
            this.label5.TabIndex = 8;
            this.label5.Text = "Enter Number of times a pateint take medicine in a day";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 252);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Time 1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(33, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(466, 24);
            this.label7.TabIndex = 11;
            this.label7.Text = "Enter Number of times a patient is checked up in a day";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(53, 340);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = " Time 1";
            // 
            // TextboxPatName
            // 
            this.TextboxPatName.Location = new System.Drawing.Point(238, 74);
            this.TextboxPatName.Name = "TextboxPatName";
            this.TextboxPatName.Size = new System.Drawing.Size(149, 31);
            this.TextboxPatName.TabIndex = 16;
            // 
            // TextboxDocName
            // 
            this.TextboxDocName.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextboxDocName.Location = new System.Drawing.Point(283, 217);
            this.TextboxDocName.MaxLength = 32760;
            this.TextboxDocName.Multiline = true;
            this.TextboxDocName.Name = "TextboxDocName";
            this.TextboxDocName.Size = new System.Drawing.Size(172, 30);
            this.TextboxDocName.TabIndex = 17;
            // 
            // TextboxNurName
            // 
            this.TextboxNurName.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextboxNurName.Location = new System.Drawing.Point(288, 216);
            this.TextboxNurName.Multiline = true;
            this.TextboxNurName.Name = "TextboxNurName";
            this.TextboxNurName.Size = new System.Drawing.Size(169, 31);
            this.TextboxNurName.TabIndex = 18;
            // 
            // TextboxNMT
            // 
            this.TextboxNMT.Location = new System.Drawing.Point(505, 207);
            this.TextboxNMT.Name = "TextboxNMT";
            this.TextboxNMT.Size = new System.Drawing.Size(44, 31);
            this.TextboxNMT.TabIndex = 19;
            this.TextboxNMT.TextChanged += new System.EventHandler(this.NMT_TextChanged);
            // 
            // TextboxMT1
            // 
            this.TextboxMT1.Enabled = false;
            this.TextboxMT1.Location = new System.Drawing.Point(115, 245);
            this.TextboxMT1.Name = "TextboxMT1";
            this.TextboxMT1.Size = new System.Drawing.Size(96, 31);
            this.TextboxMT1.TabIndex = 20;
            // 
            // TextboxNCT
            // 
            this.TextboxNCT.Location = new System.Drawing.Point(505, 292);
            this.TextboxNCT.Name = "TextboxNCT";
            this.TextboxNCT.Size = new System.Drawing.Size(44, 31);
            this.TextboxNCT.TabIndex = 21;
            this.TextboxNCT.TextChanged += new System.EventHandler(this.NCT_TextChanged);
            // 
            // TextboxCT1
            // 
            this.TextboxCT1.Enabled = false;
            this.TextboxCT1.Location = new System.Drawing.Point(115, 333);
            this.TextboxCT1.Name = "TextboxCT1";
            this.TextboxCT1.Size = new System.Drawing.Size(96, 31);
            this.TextboxCT1.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft PhagsPa", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(22, 162);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(540, 32);
            this.label9.TabIndex = 23;
            this.label9.Text = "Enter time in 24 hr clock system as HH:MM:SS";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(381, 253);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 20);
            this.label11.TabIndex = 25;
            this.label11.Text = "Time 3";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(213, 253);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 20);
            this.label12.TabIndex = 26;
            this.label12.Text = " Time 2";
            // 
            // TextboxMT2
            // 
            this.TextboxMT2.Enabled = false;
            this.TextboxMT2.Location = new System.Drawing.Point(279, 245);
            this.TextboxMT2.Name = "TextboxMT2";
            this.TextboxMT2.Size = new System.Drawing.Size(96, 31);
            this.TextboxMT2.TabIndex = 27;
            // 
            // TextboxMT3
            // 
            this.TextboxMT3.Enabled = false;
            this.TextboxMT3.Location = new System.Drawing.Point(442, 246);
            this.TextboxMT3.Name = "TextboxMT3";
            this.TextboxMT3.Size = new System.Drawing.Size(96, 31);
            this.TextboxMT3.TabIndex = 28;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(217, 340);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 20);
            this.label10.TabIndex = 29;
            this.label10.Text = "Time 2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(380, 340);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 20);
            this.label13.TabIndex = 30;
            this.label13.Text = " Time 3 ";
            // 
            // TextboxCT2
            // 
            this.TextboxCT2.Enabled = false;
            this.TextboxCT2.Location = new System.Drawing.Point(279, 333);
            this.TextboxCT2.Name = "TextboxCT2";
            this.TextboxCT2.Size = new System.Drawing.Size(98, 31);
            this.TextboxCT2.TabIndex = 31;
            // 
            // TextboxCT3
            // 
            this.TextboxCT3.Enabled = false;
            this.TextboxCT3.Location = new System.Drawing.Point(442, 333);
            this.TextboxCT3.Name = "TextboxCT3";
            this.TextboxCT3.Size = new System.Drawing.Size(98, 31);
            this.TextboxCT3.TabIndex = 32;
            // 
            // Adddoctor
            // 
            this.Adddoctor.BackColor = System.Drawing.Color.White;
            this.Adddoctor.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adddoctor.ForeColor = System.Drawing.Color.Purple;
            this.Adddoctor.Location = new System.Drawing.Point(310, 107);
            this.Adddoctor.Name = "Adddoctor";
            this.Adddoctor.Size = new System.Drawing.Size(136, 118);
            this.Adddoctor.TabIndex = 33;
            this.Adddoctor.Text = "Add Doctor";
            this.Adddoctor.UseVisualStyleBackColor = false;
            this.Adddoctor.Click += new System.EventHandler(this.Adddoctor_Click);
            // 
            // Addpatient
            // 
            this.Addpatient.BackColor = System.Drawing.Color.White;
            this.Addpatient.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addpatient.ForeColor = System.Drawing.Color.Purple;
            this.Addpatient.Location = new System.Drawing.Point(145, 107);
            this.Addpatient.Name = "Addpatient";
            this.Addpatient.Size = new System.Drawing.Size(138, 118);
            this.Addpatient.TabIndex = 34;
            this.Addpatient.Text = "Add Patient";
            this.Addpatient.UseVisualStyleBackColor = false;
            this.Addpatient.Click += new System.EventHandler(this.Addpatient_Click);
            // 
            // Addnurse
            // 
            this.Addnurse.BackColor = System.Drawing.Color.White;
            this.Addnurse.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addnurse.ForeColor = System.Drawing.Color.Purple;
            this.Addnurse.Location = new System.Drawing.Point(145, 250);
            this.Addnurse.Name = "Addnurse";
            this.Addnurse.Size = new System.Drawing.Size(138, 118);
            this.Addnurse.TabIndex = 35;
            this.Addnurse.Text = "Add Nurse";
            this.Addnurse.UseVisualStyleBackColor = false;
            this.Addnurse.Click += new System.EventHandler(this.Addnurse_Click);
            // 
            // SearchPatient
            // 
            this.SearchPatient.BackColor = System.Drawing.Color.White;
            this.SearchPatient.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchPatient.ForeColor = System.Drawing.Color.Purple;
            this.SearchPatient.Location = new System.Drawing.Point(310, 250);
            this.SearchPatient.Name = "SearchPatient";
            this.SearchPatient.Size = new System.Drawing.Size(136, 118);
            this.SearchPatient.TabIndex = 36;
            this.SearchPatient.Text = "Search Patient";
            this.SearchPatient.UseVisualStyleBackColor = false;
            this.SearchPatient.Click += new System.EventHandler(this.SearchPatient_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(-4, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(600, 473);
            this.tabControl1.TabIndex = 37;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGray;
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.LabelDateTime);
            this.tabPage1.Controls.Add(this.Adddoctor);
            this.tabPage1.Controls.Add(this.SearchPatient);
            this.tabPage1.Controls.Add(this.Addnurse);
            this.tabPage1.Controls.Add(this.Addpatient);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(592, 447);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Main Menu";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Purple;
            this.label15.Location = new System.Drawing.Point(144, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(317, 55);
            this.label15.TabIndex = 38;
            this.label15.Text = "MAIN MENU";
            // 
            // LabelDateTime
            // 
            this.LabelDateTime.AutoSize = true;
            this.LabelDateTime.Font = new System.Drawing.Font("Segoe Script", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDateTime.ForeColor = System.Drawing.Color.Purple;
            this.LabelDateTime.Location = new System.Drawing.Point(61, 371);
            this.LabelDateTime.Name = "LabelDateTime";
            this.LabelDateTime.Size = new System.Drawing.Size(203, 53);
            this.LabelDateTime.TabIndex = 37;
            this.LabelDateTime.Text = "Date Time";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightBlue;
            this.tabPage2.Controls.Add(this.TextboxPatRoomNo);
            this.tabPage2.Controls.Add(this.TextboxPatId);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.labelID);
            this.tabPage2.Controls.Add(this.comboboxNurName);
            this.tabPage2.Controls.Add(this.comboboxDocName);
            this.tabPage2.Controls.Add(this.buttonback);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.PatSubmit);
            this.tabPage2.Controls.Add(this.TextboxCT3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.TextboxCT2);
            this.tabPage2.Controls.Add(this.TextboxPatName);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.TextboxCT1);
            this.tabPage2.Controls.Add(this.TextboxMT3);
            this.tabPage2.Controls.Add(this.TextboxNCT);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.TextboxMT2);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.TextboxNMT);
            this.tabPage2.Controls.Add(this.TextboxMT1);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(592, 447);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Add Patient";
            // 
            // TextboxPatRoomNo
            // 
            this.TextboxPatRoomNo.Location = new System.Drawing.Point(481, 74);
            this.TextboxPatRoomNo.Name = "TextboxPatRoomNo";
            this.TextboxPatRoomNo.Size = new System.Drawing.Size(57, 31);
            this.TextboxPatRoomNo.TabIndex = 40;
            // 
            // TextboxPatId
            // 
            this.TextboxPatId.Location = new System.Drawing.Point(63, 74);
            this.TextboxPatId.Name = "TextboxPatId";
            this.TextboxPatId.Size = new System.Drawing.Size(68, 31);
            this.TextboxPatId.TabIndex = 39;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(393, 78);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 24);
            this.label14.TabIndex = 38;
            this.label14.Text = "Room No";
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelID.Location = new System.Drawing.Point(33, 78);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(27, 24);
            this.labelID.TabIndex = 37;
            this.labelID.Text = "ID";
            // 
            // comboboxNurName
            // 
            this.comboboxNurName.FormattingEnabled = true;
            this.comboboxNurName.Location = new System.Drawing.Point(384, 115);
            this.comboboxNurName.Name = "comboboxNurName";
            this.comboboxNurName.Size = new System.Drawing.Size(154, 33);
            this.comboboxNurName.TabIndex = 36;
            // 
            // comboboxDocName
            // 
            this.comboboxDocName.FormattingEnabled = true;
            this.comboboxDocName.Location = new System.Drawing.Point(134, 115);
            this.comboboxDocName.Name = "comboboxDocName";
            this.comboboxDocName.Size = new System.Drawing.Size(149, 33);
            this.comboboxDocName.TabIndex = 35;
            // 
            // buttonback
            // 
            this.buttonback.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.buttonback.Font = new System.Drawing.Font("Microsoft PhagsPa", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonback.Location = new System.Drawing.Point(63, 383);
            this.buttonback.Name = "buttonback";
            this.buttonback.Size = new System.Drawing.Size(93, 34);
            this.buttonback.TabIndex = 34;
            this.buttonback.Text = "Back";
            this.buttonback.UseVisualStyleBackColor = false;
            this.buttonback.Click += new System.EventHandler(this.buttonback_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabPage3.Controls.Add(this.buttonback2);
            this.tabPage3.Controls.Add(this.ButtonDocSubmit);
            this.tabPage3.Controls.Add(this.TextboxDocId);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.TextboxDocName);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(592, 447);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Add Doctor";
            // 
            // buttonback2
            // 
            this.buttonback2.BackColor = System.Drawing.Color.Crimson;
            this.buttonback2.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonback2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonback2.Location = new System.Drawing.Point(67, 369);
            this.buttonback2.Name = "buttonback2";
            this.buttonback2.Size = new System.Drawing.Size(100, 36);
            this.buttonback2.TabIndex = 23;
            this.buttonback2.Text = "Back";
            this.buttonback2.UseVisualStyleBackColor = false;
            this.buttonback2.Click += new System.EventHandler(this.buttonback2_Click);
            // 
            // ButtonDocSubmit
            // 
            this.ButtonDocSubmit.BackColor = System.Drawing.Color.Crimson;
            this.ButtonDocSubmit.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonDocSubmit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButtonDocSubmit.Location = new System.Drawing.Point(422, 369);
            this.ButtonDocSubmit.Name = "ButtonDocSubmit";
            this.ButtonDocSubmit.Size = new System.Drawing.Size(101, 36);
            this.ButtonDocSubmit.TabIndex = 22;
            this.ButtonDocSubmit.Text = "Submit";
            this.ButtonDocSubmit.UseVisualStyleBackColor = false;
            this.ButtonDocSubmit.Click += new System.EventHandler(this.button1_Click);
            // 
            // TextboxDocId
            // 
            this.TextboxDocId.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextboxDocId.Location = new System.Drawing.Point(283, 159);
            this.TextboxDocId.Multiline = true;
            this.TextboxDocId.Name = "TextboxDocId";
            this.TextboxDocId.Size = new System.Drawing.Size(172, 30);
            this.TextboxDocId.TabIndex = 21;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(214, 164);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(32, 25);
            this.label20.TabIndex = 20;
            this.label20.Text = "ID";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(137, 222);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(109, 25);
            this.label19.TabIndex = 19;
            this.label19.Text = "Full Name";
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Crimson;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(165, 0, 0, 0);
            this.label16.Size = new System.Drawing.Size(592, 34);
            this.label16.TabIndex = 18;
            this.label16.Text = "Doctor Information";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.LightYellow;
            this.tabPage4.Controls.Add(this.TextboxNurId);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.buttonback3);
            this.tabPage4.Controls.Add(this.buttonNurSubmit);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.TextboxNurName);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(592, 447);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Add Nurse";
            // 
            // TextboxNurId
            // 
            this.TextboxNurId.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextboxNurId.Location = new System.Drawing.Point(288, 158);
            this.TextboxNurId.Multiline = true;
            this.TextboxNurId.Name = "TextboxNurId";
            this.TextboxNurId.Size = new System.Drawing.Size(169, 31);
            this.TextboxNurId.TabIndex = 24;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(213, 164);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 25);
            this.label22.TabIndex = 23;
            this.label22.Text = "ID";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(136, 222);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(109, 25);
            this.label21.TabIndex = 22;
            this.label21.Text = "Full Name";
            // 
            // buttonback3
            // 
            this.buttonback3.BackColor = System.Drawing.Color.Yellow;
            this.buttonback3.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonback3.Location = new System.Drawing.Point(62, 370);
            this.buttonback3.Name = "buttonback3";
            this.buttonback3.Size = new System.Drawing.Size(101, 32);
            this.buttonback3.TabIndex = 21;
            this.buttonback3.Text = "Back";
            this.buttonback3.UseVisualStyleBackColor = false;
            this.buttonback3.Click += new System.EventHandler(this.buttonback3_Click);
            // 
            // buttonNurSubmit
            // 
            this.buttonNurSubmit.BackColor = System.Drawing.Color.Yellow;
            this.buttonNurSubmit.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNurSubmit.Location = new System.Drawing.Point(423, 370);
            this.buttonNurSubmit.Name = "buttonNurSubmit";
            this.buttonNurSubmit.Size = new System.Drawing.Size(101, 32);
            this.buttonNurSubmit.TabIndex = 20;
            this.buttonNurSubmit.Text = "Submit";
            this.buttonNurSubmit.UseVisualStyleBackColor = false;
            this.buttonNurSubmit.Click += new System.EventHandler(this.button3_Click);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Yellow;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(0, 0);
            this.label17.Name = "label17";
            this.label17.Padding = new System.Windows.Forms.Padding(175, 0, 0, 0);
            this.label17.Size = new System.Drawing.Size(592, 33);
            this.label17.TabIndex = 19;
            this.label17.Text = "Nurse Information";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage5.Controls.Add(this.tableLayoutPanel1);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.label23);
            this.tabPage5.Controls.Add(this.TextboxPatSearch);
            this.tabPage5.Controls.Add(this.buttonback4);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(592, 447);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Search Patient";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Green;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.InsetDouble;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 133F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel1.Controls.Add(this.label25, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.LabelPatID, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.LabelPatientName, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.LabelRoomNo, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.LabelNurseName, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.LabelDocName, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label28, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label26, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label27, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 233);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.85185F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.14815F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(574, 81);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(80, 3);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(115, 21);
            this.label25.TabIndex = 1;
            this.label25.Text = "Patient Name";
            // 
            // LabelPatID
            // 
            this.LabelPatID.AutoSize = true;
            this.LabelPatID.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPatID.Location = new System.Drawing.Point(6, 43);
            this.LabelPatID.Name = "LabelPatID";
            this.LabelPatID.Size = new System.Drawing.Size(0, 19);
            this.LabelPatID.TabIndex = 5;
            // 
            // LabelPatientName
            // 
            this.LabelPatientName.AutoSize = true;
            this.LabelPatientName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelPatientName.Location = new System.Drawing.Point(80, 43);
            this.LabelPatientName.Name = "LabelPatientName";
            this.LabelPatientName.Size = new System.Drawing.Size(0, 18);
            this.LabelPatientName.TabIndex = 6;
            // 
            // LabelRoomNo
            // 
            this.LabelRoomNo.AutoSize = true;
            this.LabelRoomNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelRoomNo.Location = new System.Drawing.Point(484, 43);
            this.LabelRoomNo.Name = "LabelRoomNo";
            this.LabelRoomNo.Size = new System.Drawing.Size(0, 18);
            this.LabelRoomNo.TabIndex = 9;
            // 
            // LabelNurseName
            // 
            this.LabelNurseName.AutoSize = true;
            this.LabelNurseName.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelNurseName.Location = new System.Drawing.Point(348, 43);
            this.LabelNurseName.Name = "LabelNurseName";
            this.LabelNurseName.Size = new System.Drawing.Size(0, 19);
            this.LabelNurseName.TabIndex = 10;
            // 
            // LabelDocName
            // 
            this.LabelDocName.AutoSize = true;
            this.LabelDocName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelDocName.Location = new System.Drawing.Point(225, 43);
            this.LabelDocName.Name = "LabelDocName";
            this.LabelDocName.Size = new System.Drawing.Size(0, 18);
            this.LabelDocName.TabIndex = 7;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(484, 3);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(76, 19);
            this.label28.TabIndex = 4;
            this.label28.Text = "Room No";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(225, 3);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(112, 21);
            this.label26.TabIndex = 2;
            this.label26.Text = "Doctor Name";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(348, 3);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(105, 21);
            this.label27.TabIndex = 3;
            this.label27.Text = "Nurse Name";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 26);
            this.label24.TabIndex = 0;
            this.label24.Text = "Patient ID";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Green;
            this.button2.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(335, 120);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(86, 38);
            this.button2.TabIndex = 5;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(161, 76);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(179, 29);
            this.label23.TabIndex = 4;
            this.label23.Text = "Enter Patient ID";
            // 
            // TextboxPatSearch
            // 
            this.TextboxPatSearch.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextboxPatSearch.ForeColor = System.Drawing.SystemColors.InfoText;
            this.TextboxPatSearch.Location = new System.Drawing.Point(346, 73);
            this.TextboxPatSearch.Multiline = true;
            this.TextboxPatSearch.Name = "TextboxPatSearch";
            this.TextboxPatSearch.Size = new System.Drawing.Size(75, 32);
            this.TextboxPatSearch.TabIndex = 3;
            // 
            // buttonback4
            // 
            this.buttonback4.BackColor = System.Drawing.Color.Green;
            this.buttonback4.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonback4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonback4.Location = new System.Drawing.Point(55, 374);
            this.buttonback4.Name = "buttonback4";
            this.buttonback4.Size = new System.Drawing.Size(98, 35);
            this.buttonback4.TabIndex = 1;
            this.buttonback4.Text = "Back";
            this.buttonback4.UseVisualStyleBackColor = false;
            this.buttonback4.Click += new System.EventHandler(this.buttonback4_Click);
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Green;
            this.label18.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label18.Location = new System.Drawing.Point(-1, 0);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(200, 0, 0, 0);
            this.label18.Size = new System.Drawing.Size(593, 33);
            this.label18.TabIndex = 0;
            this.label18.Text = "Search Patient";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 470);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "PATIENT CARE AND MEDICINE REMINDER SYSTEM";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button PatSubmit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TextboxPatName;
        private System.Windows.Forms.TextBox TextboxDocName;
        private System.Windows.Forms.TextBox TextboxNurName;
        private System.Windows.Forms.TextBox TextboxNMT;
        private System.Windows.Forms.TextBox TextboxMT1;
        private System.Windows.Forms.TextBox TextboxNCT;
        private System.Windows.Forms.TextBox TextboxCT1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TextboxMT2;
        private System.Windows.Forms.TextBox TextboxMT3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TextboxCT2;
        private System.Windows.Forms.TextBox TextboxCT3;
        private System.Windows.Forms.Button Adddoctor;
        private System.Windows.Forms.Button Addpatient;
        private System.Windows.Forms.Button Addnurse;
        private System.Windows.Forms.Button SearchPatient;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label LabelDateTime;
        private System.Windows.Forms.Button buttonback;
        private System.Windows.Forms.ComboBox comboboxNurName;
        private System.Windows.Forms.ComboBox comboboxDocName;
        private System.Windows.Forms.TextBox TextboxPatRoomNo;
        private System.Windows.Forms.TextBox TextboxPatId;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button buttonback2;
        private System.Windows.Forms.Button ButtonDocSubmit;
        private System.Windows.Forms.TextBox TextboxDocId;
        private System.Windows.Forms.TextBox TextboxNurId;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button buttonback3;
        private System.Windows.Forms.Button buttonNurSubmit;
        private System.Windows.Forms.Button buttonback4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox TextboxPatSearch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label LabelPatID;
        private System.Windows.Forms.Label LabelPatientName;
        private System.Windows.Forms.Label LabelRoomNo;
        private System.Windows.Forms.Label LabelNurseName;
        private System.Windows.Forms.Label LabelDocName;
    }
}

