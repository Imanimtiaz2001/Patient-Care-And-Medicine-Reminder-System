﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AutoMEd
{

    public partial class Form1 : Form
    {
        string[] DocNameArr = new string[20];
        string[] DocIdArr = new string[20];
        int DocCount = 0;

        string[] NurNameArr = new string[20];
        string[] NurIdArr = new string[20];
        int NurCount = 0;

        string[] PatNameArr = new string[100];
        string[] PatIdArr = new string[100];
        string[] PatRoomNoArr = new string[100];
        int[] PatDocArr = new int[100];
        int[] PatNurArr = new int[100];

        string[] NumMedTimeArr = new string[100];
        string[] MedTime1Arr = new string[100];
        string[] MedTime2Arr = new string[100];
        string[] MedTime3Arr = new string[100];

        string[] NumChkUpTimeArr = new string[100];
        string[] ChkUpTime1Arr = new string[100];
        string[] ChkUpTime2Arr = new string[100];
        string[] ChkUpTime3Arr = new string[100];
        int PatCount = 0;

        int give;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Enabled = true;

            DocNameArr[0] = "Iman Imtiaz";
            DocNameArr[1] = "Hira Imtiaz";
            DocNameArr[2] = "Momina Ashiq";
            DocNameArr[3] = "Eesha Yousaf";
            DocIdArr[0] = "0";
            DocIdArr[1] = "1";
            DocIdArr[2] = "2";
            DocIdArr[3] = "3";
            DocCount = 3;
            for (int i = 0; i <= 3; i++)
            {
                comboboxDocName.Items.Add(DocNameArr[i]);
            }

            NurNameArr[0] = "Alveena Khan";
            NurNameArr[1] = "Wajeeha Muzammil";
            NurNameArr[2] = "Faria Imran";
            NurNameArr[3] = "Komal Majeed";
            NurIdArr[0] = "0";
            NurIdArr[1] = "1";
            NurIdArr[2] = "2";
            NurIdArr[3] = "3";
            NurCount = 3;
            for (int i = 0; i <= 3; i++)
            {
                comboboxNurName.Items.Add(NurNameArr[i]);
            }

            PatNameArr[0] = "Faria Imran";
            PatNameArr[1] = "Awais Khan";
            PatNameArr[2] = "Laiba Sohail";
            PatNameArr[3] = "Bisma Ijaz";
            PatIdArr[0] = "0";
            PatIdArr[1] = "1";
            PatIdArr[2] = "2";
            PatIdArr[3] = "3";
            PatRoomNoArr[0] = "20";
            PatRoomNoArr[1] = "32";
            PatRoomNoArr[2] = "6";
            PatRoomNoArr[3] = "49";

            PatDocArr[0] = 1;
            PatDocArr[1] = 0;
            PatDocArr[2] = 3;
            PatDocArr[3] = 2;
            PatNurArr[0] = 1;
            PatNurArr[1] = 0;
            PatNurArr[2] = 3;
            PatNurArr[3] = 2;

            NumMedTimeArr[0] = "3";
            NumMedTimeArr[1] = "2";
            NumMedTimeArr[2] = "1";
            NumMedTimeArr[3] = "2";

            MedTime1Arr[0] = "10:00";
            MedTime1Arr[1] = "11:00";
            MedTime1Arr[2] = "10:30";
            MedTime1Arr[3] = "12:00";

            MedTime2Arr[0] = "14:00";
            MedTime2Arr[1] = "20:00";
            MedTime2Arr[2] = "0";
            MedTime2Arr[3] = "14:30";

            MedTime3Arr[0] = "22:00";
            MedTime3Arr[1] = "0";
            MedTime3Arr[2] = "0";
            MedTime3Arr[3] = "0";


            NumChkUpTimeArr[0] = "3";
            NumChkUpTimeArr[1] = "2";
            NumChkUpTimeArr[2] = "1";
            NumChkUpTimeArr[3] = "2";

            ChkUpTime1Arr[0] = "10:30";
            ChkUpTime1Arr[1] = "11:00";
            ChkUpTime1Arr[2] = "10:00";
            ChkUpTime1Arr[3] = "12:00";

            ChkUpTime2Arr[0] = "13:00";
            ChkUpTime2Arr[1] = "15:00";
            ChkUpTime2Arr[2] = "0";
            ChkUpTime2Arr[3] = "14:30";

            ChkUpTime3Arr[0] = "23:00";
            ChkUpTime3Arr[1] = "0";
            ChkUpTime3Arr[2] = "0";
            ChkUpTime3Arr[3] = "0";
            PatCount = 3;
        }



        private void Addpatient_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }
        private void Adddoctor_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }

        private void Addnurse_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 3;
        }

        private void SearchPatient_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 4;
        }

        private void buttonback_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }
        private void buttonback2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void buttonback3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void buttonback4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
            TextboxPatSearch.Text = "";
            LabelPatID.Text = "";
            LabelPatientName.Text = "";
            LabelDocName.Text = "";
            LabelNurseName.Text = "";
            LabelRoomNo.Text = "";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LabelDateTime.Text = DateTime.Now.ToString();
            string DateBreak = DateTime.Now.ToString("HH:mm:ss");
            for (int i = 0; i <= PatCount; i++)
            {
                if (DateBreak == MedTime1Arr[i] + ":00")
                {
                    MessageBox.Show("Its time for " + NurNameArr[PatNurArr[i]] + " to give medicine to " + PatNameArr[i]);
                }
                if (DateBreak == MedTime2Arr[i] + ":00")
                {
                    MessageBox.Show("Its time for " + NurNameArr[PatNurArr[i]] + " to give medicine to " + PatNameArr[i]);
                }
                if (DateBreak == MedTime3Arr[i] + ":00")
                {
                    MessageBox.Show("Its time for " + NurNameArr[PatNurArr[i]] + " to give medicine to " + PatNameArr[i]);
                }
                if (DateBreak == ChkUpTime1Arr[i] + ":00")
                {
                    MessageBox.Show("Its time for " + DocNameArr[PatDocArr[i]] + " to check " + PatNameArr[i]);
                }
                if (DateBreak == ChkUpTime2Arr[i] + ":00")
                {
                    MessageBox.Show("Its time for " + DocNameArr[PatDocArr[i]] + " to check " + PatNameArr[i]);
                }
                if (DateBreak == ChkUpTime3Arr[i] + ":00")
                {
                    MessageBox.Show("Its time for " + DocNameArr[PatDocArr[i]] + " to check " + PatNameArr[i]);
                }
            }

        }
        private void NMT_TextChanged(object sender, EventArgs e)
        {
            if (TextboxNMT.Text == "1")
            {
                TextboxMT1.Enabled = true;
            }
            else if (TextboxNMT.Text == "2")
            {
                TextboxMT1.Enabled = true;
                TextboxMT2.Enabled = true;
            }
            else if (TextboxNMT.Text == "3")
            {
                TextboxMT1.Enabled = true;
                TextboxMT2.Enabled = true;
                TextboxMT3.Enabled = true;
            }
            else
            {
                TextboxMT1.Enabled = false;
                TextboxMT2.Enabled = false;
                TextboxMT3.Enabled = false;
                if (TextboxNMT.Text != "")
                {
                    MessageBox.Show("Maximum 3 times a medicine can be given to a patient");
                }
            }
        }
        private void NCT_TextChanged(object sender, EventArgs e)
        {
            if (TextboxNCT.Text == "1")
            {
                TextboxCT1.Enabled = true;
            }
            else if (TextboxNCT.Text == "2")
            {
                TextboxCT1.Enabled = true;
                TextboxCT2.Enabled = true;
            }
            else if (TextboxNCT.Text == "3")
            {
                TextboxCT1.Enabled = true;
                TextboxCT2.Enabled = true;
                TextboxCT3.Enabled = true;
            }
            else
            {
                TextboxCT1.Enabled = false;
                TextboxCT2.Enabled = false;
                TextboxCT3.Enabled = false;
                if (TextboxNCT.Text != "")
                {
                    MessageBox.Show("A patient can be checked up 3 times only.");
                }
            }
        }

        private void Submit_Click(object sender, EventArgs e)
        {
            if (TextboxPatName.Text != "" && TextboxPatId.Text != "" && TextboxPatRoomNo.Text != "" && TextboxNMT.Text != "" && TextboxMT1.Text != "" && TextboxNCT.Text != "" && TextboxCT1.Text != "")
            {
                PatCount++;
                PatNameArr[PatCount] = TextboxPatName.Text;
                PatIdArr[PatCount] = TextboxPatId.Text;
                PatRoomNoArr[PatCount] = TextboxPatRoomNo.Text;
                PatDocArr[PatCount] = comboboxDocName.SelectedIndex;
                PatNurArr[PatCount] = comboboxNurName.SelectedIndex;

                NumMedTimeArr[PatCount] = TextboxNMT.Text;
                MedTime1Arr[PatCount] = TextboxMT1.Text;
                if (Int32.Parse(NumMedTimeArr[PatCount]) > 1)
                {
                    MedTime2Arr[PatCount] = TextboxMT2.Text;
                }
                if (Int32.Parse(NumMedTimeArr[PatCount]) > 2)
                {
                    MedTime3Arr[PatCount] = TextboxMT3.Text;
                }


                NumChkUpTimeArr[PatCount] = TextboxNCT.Text;
                ChkUpTime1Arr[PatCount] = TextboxCT1.Text;
                if (Int32.Parse(NumChkUpTimeArr[PatCount]) > 1)
                {
                    ChkUpTime2Arr[PatCount] = TextboxCT2.Text;
                }
                if (Int32.Parse(NumChkUpTimeArr[PatCount]) > 2)
                {
                    ChkUpTime3Arr[PatCount] = TextboxCT3.Text;
                }

                MessageBox.Show("Patient information added successfully.");
                TextboxPatName.Text = "";
                TextboxPatId.Text = "";
                TextboxPatRoomNo.Text = "";
                TextboxNMT.Text = "";
                TextboxNCT.Text = "";
                TextboxMT1.Text = "";
                TextboxMT2.Text = "";
                TextboxMT3.Text = "";
                TextboxCT1.Text = "";
                TextboxCT2.Text = "";
                TextboxCT3.Text = "";
            }
            else
            {
                MessageBox.Show("Please enter complete patient details first.");
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (TextboxDocName.Text != "" && TextboxDocId.Text != "")
            {
                DocCount++;
                DocNameArr[DocCount] = TextboxDocName.Text;
                comboboxDocName.Items.Add(DocNameArr[DocCount]);
                DocIdArr[DocCount] = TextboxDocId.Text;
                MessageBox.Show("Doctor information added successfully.");
                TextboxDocName.Text = "";
                TextboxDocId.Text = "";
            }
            else
            {
                MessageBox.Show("Please enter complete doctor details first.");
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (TextboxNurName.Text != "" && TextboxNurId.Text != "")
            {
                NurCount++;
                NurNameArr[NurCount] = TextboxNurName.Text;
                comboboxNurName.Items.Add(NurNameArr[NurCount]);
                NurIdArr[NurCount] = TextboxNurId.Text;
                MessageBox.Show("Nurse information added successfully.");
                TextboxNurName.Text = "";
                TextboxNurId.Text = "";
            }
            else
            {
                MessageBox.Show("Please enter complete nurse details first.");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        { 
            if (TextboxPatSearch.Text != "")
            {
                for (int i = 0; i <= PatCount; i++)
                {
                    if (TextboxPatSearch.Text == PatIdArr[i])
                    {
                        LabelPatID.Text = TextboxPatSearch.Text;
                        LabelPatientName.Text = PatNameArr[i];
                        LabelDocName.Text = DocNameArr[PatDocArr[i]];
                        LabelNurseName.Text = NurNameArr[PatNurArr[i]];
                        LabelRoomNo.Text = PatRoomNoArr[i];
                    }
                }
            }
            else
            {
                MessageBox.Show("Enter ID first.");
            }
        }
    }
}


   

